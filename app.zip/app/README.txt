
TITLE: 
App - Free HTML5 App Template Built with Bootstrap 4

AUTHOR:
DESIGNED & DEVELOPED by FreeHTML5.co

Website: http://freehtml5.co/
Twitter: http://twitter.com/fh5co
Facebook: http://facebook.com/fh5co


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://www.google.com/fonts/

Font Awesome
http://fontawesome.io

animate.css
http://daneden.me/animate

Owl Carousel
http://www.owlcarousel.owlgraphic.com/
